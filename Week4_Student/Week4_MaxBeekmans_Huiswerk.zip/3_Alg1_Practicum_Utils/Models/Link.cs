﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alg1_Practicum_Utils.Models
{
    public class Link
    {
        public NAW Naw { get; set; }
        public Link Next { get; set; }
    }
}
